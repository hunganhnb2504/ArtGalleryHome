import React from 'react'

function ListEvent() {
  return (
    <div>
       <link rel="stylesheet" href="assets/css/event.css" />

      <div className='listEvent-page'>
      <div className="title-event_page">
            <h1> Events </h1>
            
          </div>
          <div className="main-now_event">
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
            <a className="card-event">
              <div className="img-event_card">
                <img src="assets/images/arts/art1.jpeg"></img>
              </div>
              <div className="info-event_card">
                <div className="name-event_card">
                  Spanish Painting: XIV-XVIII Centuries
                </div>
                <div className="time-event_card">07 JULY - 07/09</div>
              </div>
            </a>
          </div>
      </div>
    </div>
  )
}

export default ListEvent
