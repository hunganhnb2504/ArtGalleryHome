import React from "react";

function ListViewingroom() {
  return (
    <div>
      <link rel="stylesheet" href="assets/css/view.css" />

      <div className="listViewroom-page">
        <div className="title-page">
          <h1 id="title-listView"> List Rooms</h1>
        </div>
        <div className="lastest-card">
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            <div className="card-viewingrooms">
              <div className="img_featured-card">
                <img src="assets/images/viewingroom/room1.webp" alt="Image 1" />
              </div>
              <div className="content_featured-card">
                <h3 className="name-room">Allen Jones - 'From the Gods'</h3>
                <p className="name-artist">Almine Rech</p>
              </div>
            </div>
            
            
          </div>
      </div>
    </div>
  );
}

export default ListViewingroom;
