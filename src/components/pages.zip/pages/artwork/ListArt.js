import React from "react";

function ListArt() {
  return (
    <div>
      <link rel="stylesheet" href="assets/css/art.css" />

      <div className="ListArt_page">
        <div className="top-page">
          <h1 className="title-art_page">Our Artworks</h1>
          <h3>COMTEMPORARY</h3>
        </div>
        <div className="content-section">
          <div className="card-art_home">
            <a  href="/artworkDetail">
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a href="/artworkDetail">
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a href="/artworkDetail">
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a href="/artworkDetail">
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a href="/artworkDetail">
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a href="/artworkDetail">
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a href="/artworkDetail">
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a href="/artworkDetail">
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a href="/artworkDetail">
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a>
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a>
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
          <div className="card-art_home">
            <a>
              <img src="assets/images/arts/art2.jpeg" alt="Image 1" />
              <h2 className="name-artist_carousel">Gordian Knot Wood</h2>
              <h2 className="exhibition">Perfomer, 2024</h2>
              <span className="price-art_carousel">$10,000-$35,000</span>
            </a>
            <a className="button_add-product">Purchase</a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ListArt;
